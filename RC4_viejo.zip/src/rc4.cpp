/*
 * Author:  Hugo Fernández Solís
 * Project: Práctica 2 - Cifrado RC4
 * File:    rc4.cpp - Contains the main function of the assignment.
 * 
 * References:
 *    C++:        https://www.cplusplus.com/reference/
 *    ULL:        https://campusingenieriaytecnologia.ull.es/mod/assign/view.php?id=282127
 *    Wikipedia:  https://en.wikipedia.org/wiki/Vigenère_cipher
 */

#include <iostream>

#include "Rc4Cipher.h"


int main(void) {
  std::string key, message;
	std::cout << "=== PROGRAMA DE ENCRIPTADO DE VIGENERE ===\n\n"
						<< "Inserte la clave: ";
	std::getline(std::cin, key);
	
	std::cout << "Inserte el mensaje a cifrar: ";
	std::getline(std::cin, message);

	Rc4Cipher cipher(key);
	std::vector<unsigned> encrypted = cipher.encrypt(message);
	std::vector<unsigned> decrypted = cipher.decrypt(encrypted);

	std::cout << "\nMensaje cifrado: "; 
  for(const unsigned& digit : encrypted) {
    std::cout << digit << ", ";
  }
  std::cout << "\b\b  " << std::endl;
	std::cout << "\nMensaje descifrado: "; 
  for(const unsigned& digit : decrypted) {
    std::cout << (char)digit << ", ";
  }
  std::cout << "\b\b  " << std::endl;
	std::cout << std::endl;
}